<?php
// public_html/sofia-rooms.com/api.php
require_once __DIR__ . '/app/bootstrap.php';
ensure_migrated();
require_csrf();

header('Content-Type: application/json; charset=UTF-8');

$action  = $_GET['action'] ?? '';
$list_id = (int)($_GET['list_id'] ?? ($_POST['list_id'] ?? 1));

require_auth($list_id); // αν δεν είσαι logged-in, απαντά JSON 401

function j($data, int $code = 200): void {
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function progress(PDO $pdo, int $list_id): array {
  $s = $pdo->prepare('SELECT SUM(checked) AS done, COUNT(*) AS total FROM tasks WHERE list_id=?');
  $s->execute([$list_id]);
  $r = $s->fetch();
  $done = (int)($r['done'] ?? 0);
  $total = (int)($r['total'] ?? 0);
  $pct = $total > 0 ? (int)round($done / $total * 100) : 0;
  return ['done'=>$done,'total'=>$total,'percent'=>$pct];
}

try {
  // Συνδέσου ΜΕΣΑ στο try για να πιαστεί τυχόν PDO exception
  $pdo = DB::conn();

  switch ($action) {
    case 'bootstrap': {
      $q = $pdo->prepare('SELECT id,title,description,note,checked,position,priority,tags FROM tasks WHERE list_id=? ORDER BY position,id');
      $q->execute([$list_id]);
      $tasks = $q->fetchAll();
      foreach ($tasks as &$t) { $t['checked'] = (int)$t['checked']; $t['priority'] = (int)$t['priority']; }

      $q2 = $pdo->prepare('SELECT id,name,location,date_label,owner,phone,notes,materials FROM lists WHERE id=?');
      $q2->execute([$list_id]);
      $meta = $q2->fetch() ?: [];

      j(['ok'=>true,'tasks'=>$tasks,'meta'=>$meta,'progress'=>progress($pdo,$list_id),'csrf'=>csrf_token()]);
    }

    case 'toggle': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $id = (int)($b['id'] ?? 0); $checked = !empty($b['checked']) ? 1 : 0;
      $pdo->prepare('UPDATE tasks SET checked=? WHERE id=? AND list_id=?')->execute([$checked,$id,$list_id]);
      j(['ok'=>true]);
    }

    case 'note': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $id = (int)($b['id'] ?? 0); $note = trim((string)($b['note'] ?? ''));
      $pdo->prepare('UPDATE tasks SET note=? WHERE id=? AND list_id=?')->execute([$note,$id,$list_id]);
      j(['ok'=>true]);
    }

    case 'add': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $title = trim((string)($b['title'] ?? ''));
      if ($title==='') j(['ok'=>false,'error'=>'Title required'],400);
      $desc  = trim((string)($b['description'] ?? ''));
      $prio  = (int)($b['priority'] ?? 2); if ($prio<1 || $prio>3) $prio = 2;
      $tags  = trim((string)($b['tags'] ?? ''));

      $posS = $pdo->prepare('SELECT COALESCE(MAX(position),0)+1 FROM tasks WHERE list_id=?');
      $posS->execute([$list_id]);
      $pos = (int)$posS->fetchColumn();

      $st = $pdo->prepare('INSERT INTO tasks(list_id,title,description,position,priority,tags) VALUES (?,?,?,?,?,?)');
      $st->execute([$list_id,$title,$desc,$pos,$prio,$tags]);

      $id = (int)$pdo->lastInsertId();
      $tq = $pdo->prepare('SELECT id,title,description,note,checked,position,priority,tags FROM tasks WHERE id=?');
      $tq->execute([$id]);
      $task = $tq->fetch();
      $task['checked']  = (int)$task['checked'];
      $task['priority'] = (int)$task['priority'];

      j(['ok'=>true,'task'=>$task]);
    }

    case 'delete': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $id = (int)($b['id'] ?? 0);
      $pdo->prepare('DELETE FROM tasks WHERE id=? AND list_id=?')->execute([$id,$list_id]);
      j(['ok'=>true]);
    }

    case 'update_meta': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $pdo->prepare('UPDATE lists SET date_label=?, owner=?, phone=?, notes=?, materials=? WHERE id=?')
          ->execute([(string)($b['date_label'] ?? ''),(string)($b['owner'] ?? ''),(string)($b['phone'] ?? ''),(string)($b['notes'] ?? ''),(string)($b['materials'] ?? ''),$list_id]);
      j(['ok'=>true]);
    }

    case 'reorder': {
      $b = json_decode(file_get_contents('php://input'), true) ?: [];
      $ids = isset($b['ids']) && is_array($b['ids']) ? array_map('intval',$b['ids']) : [];
      if (!$ids) j(['ok'=>false,'error'=>'No ids'],400);

      $pdo->beginTransaction();
      $pos = 1;
      $st = $pdo->prepare('UPDATE tasks SET position=? WHERE id=? AND list_id=?');
      foreach ($ids as $id) $st->execute([$pos++, $id, $list_id]);
      $pdo->commit();

      j(['ok'=>true]);
    }

    default:
      j(['ok'=>false,'error'=>'Unknown action'],404);
  }
} catch (Throwable $e) {
  // ΠΑΝΤΑ JSON, ποτέ HTML
  j(['ok'=>false,'error'=>'Server error','detail'=>$e->getMessage()], 500);
}
