// assets/js/app.js
const el  = (sel, root=document) => root.querySelector(sel);
const els = (sel, root=document) => Array.from(root.querySelectorAll(sel));
const CSRF = () => document.querySelector('meta[name="csrf-token"]').content;
const LIST_ID = Number(new URLSearchParams(location.search).get('list_id') || 1);

const API = (action, payload, params = {}) => {
  const url = new URL('api.php', window.location.href);
  url.searchParams.set('action', action);
  url.searchParams.set('list_id', params.list_id || LIST_ID);
  const opts = payload
    ? { method:'POST', headers:{ 'Content-Type':'application/json', 'X-CSRF-Token': CSRF() }, body: JSON.stringify(payload) }
    : { headers:{ 'X-CSRF-Token': CSRF() } };
  return fetch(url.toString(), opts).then(r => r.json()).then(j => { if(!j.ok) throw new Error(j.error || 'Σφάλμα'); return j; });
};

function escapeHtml(s){ return (s||'').replace(/[&<>]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
function escapeAttr(s){ return (s||'').replace(/"/g,'&quot;'); }

let BOOT = null; // τελευταία bootstrap απάντηση (για offline fallback rendering)

function chip(text){ const span=document.createElement('span'); span.className='chip'; span.textContent=text; return span; }
function prioBadge(p){
  const map = {1:'Υψηλή',2:'Μεσαία',3:'Χαμηλή'};
  const b = document.createElement('span');
  b.className = 'badge p'+(p||2);
  b.textContent = map[p||2];
  return b;
}

function taskItem(t){
  const li = document.createElement('li');
  li.className = 'task';
  if (t.checked) li.classList.add('done');
  li.dataset.id = t.id;
  li.dataset.priority = t.priority || 2;
  li.dataset.tags = (t.tags || '').toLowerCase();
  li.draggable = true;

  li.innerHTML = `
    <div class="handle" title="Μετακίνηση">≡</div>
    <input type="checkbox" ${t.checked? 'checked':''} />
    <div class="content">
      <div class="titleRow">
        <label>${escapeHtml(t.title)}</label>
        ${prioBadge(t.priority).outerHTML}
      </div>
      <div class="desc">${escapeHtml(t.description || '')}</div>
      ${renderChips(t.tags)}
      <input class="note" placeholder="Σημειώσεις" value="${escapeAttr(t.note || '')}">
    </div>
    <div class="actions">
      <button class="del" title="Διαγραφή">🗑️</button>
    </div>
  `;

  // Toggle
  el('input[type="checkbox"]', li).addEventListener('change', async e => {
    try { await API('toggle', {id: t.id, checked: e.target.checked}); 
      li.classList.toggle('done', e.target.checked);
      refreshProgress(); 
    } catch(err){ alert(err.message); e.target.checked = !e.target.checked; }
  });

  // Notes
  el('.note', li).addEventListener('change', async e => {
    try { await API('note', {id: t.id, note: e.target.value}); }
    catch(err){ alert(err.message); }
  });

  // Delete
  el('.del', li).addEventListener('click', async () => {
    if(!confirm('Διαγραφή εργασίας;')) return;
    try { await API('delete', {id: t.id}); li.remove(); refreshProgress(); }
    catch(err){ alert(err.message); }
  });

  // Drag events
  li.addEventListener('dragstart', e => { li.classList.add('dragging'); e.dataTransfer.effectAllowed='move'; });
  li.addEventListener('dragend',   async e => { li.classList.remove('dragging'); await sendOrder(); });

  return li;
}

function renderChips(tags){
  const ctn = document.createElement('div');
  ctn.className = 'chips';
  const parts = (tags || '').split(',').map(s => s.trim()).filter(Boolean);
  parts.forEach(t => ctn.appendChild(chip(t)));
  return ctn.outerHTML;
}

async function load(){
  try {
    const data = await API('bootstrap'); // GET
    BOOT = data; // κράτα για offline
    render(data);
  } catch (err) {
    if (BOOT) { render(BOOT); } // offline fallback
    else { alert('Αποτυχία φόρτωσης: ' + err.message); }
  }
}

function render(data){
  const list = el('#taskList'); list.innerHTML = '';
  data.tasks.forEach(t => list.appendChild(taskItem(t)));
  el('#dateField').value = data.meta.date_label || '';
  el('#ownerField').value = data.meta.owner || '';
  el('#phoneField').value = data.meta.phone || '';
  el('#notes').value = data.meta.notes || '';
  el('#materials').value = data.meta.materials || '';
  updateProgress(data.progress);
  attachListDnD();
  applyFilters(); // αρχική εφαρμογή
}

function updateProgress(p){
  el('#percentText').textContent = (p.percent||0) + '%';
  el('#bar').style.width = (p.percent||0) + '%';
  el('#progressField').value = `${p.done||0} / ${p.total||0} (${p.percent||0}%)`;
}

async function refreshProgress(){ const d = await API('bootstrap'); updateProgress(d.progress); }

['#notes','#materials','#ownerField','#phoneField','#dateField'].forEach(sel=>{
  el(sel).addEventListener('change', async () => {
    try{
      await API('update_meta',{
        notes: el('#notes').value, materials: el('#materials').value,
        owner: el('#ownerField').value, phone: el('#phoneField').value,
        date_label: el('#dateField').value
      });
    }catch(err){ alert(err.message); }
  });
});

el('#addBtn')?.addEventListener('click', async () => {
  const title = el('#addTitle').value.trim();
  const description = el('#addDesc').value.trim();
  const priority = Number(el('#addPriority').value || 2);
  const tags = el('#addTags').value.trim();
  if(!title){ alert('Συμπληρώστε τίτλο'); return; }
  try {
    const {task} = await API('add', {title, description, priority, tags});
    el('#taskList').appendChild(taskItem(task));
    el('#addTitle').value = ''; el('#addDesc').value = ''; el('#addTags').value='';
    el('#addPriority').value='2';
    refreshProgress(); applyFilters();
  } catch(err){ alert(err.message); }
});

el('#printBtn').addEventListener('click', () => window.print());
el('#resetBtn').addEventListener('click', async () => {
  if(!confirm('Σίγουρα θέλετε να καθαρίσετε όλες τις επιλογές; (Η εργασία #4 θα παραμείνει ολοκληρωμένη)')) return;
  try { await API('reset', {}); await load(); } catch(err){ alert(err.message); }
});

/* ========= Filters ========= */
['#filterSearch','#filterTag','#filterPriority','#filterPending'].forEach(sel=>{
  el(sel)?.addEventListener('input', applyFilters);
  el(sel)?.addEventListener('change', applyFilters);
});
function applyFilters(){
  const q = (el('#filterSearch')?.value || '').toLowerCase();
  const tg = (el('#filterTag')?.value || '').toLowerCase();
  const pr = (el('#filterPriority')?.value || '');
  const onlyPending = !!el('#filterPending')?.checked;

  els('.task').forEach(li=>{
    const title = (li.querySelector('label')?.textContent || '').toLowerCase();
    const desc  = (li.querySelector('.desc')?.textContent || '').toLowerCase();
    const tags  = (li.dataset.tags || '');
    const prio  = (li.dataset.priority || '');
    const done  = li.querySelector('input[type="checkbox"]').checked;

    let ok = true;
    if (q && !(title.includes(q) || desc.includes(q))) ok = false;
    if (tg && !tags.split(',').map(s=>s.trim()).filter(Boolean).some(x => x.includes(tg))) ok = false;
    if (pr && pr !== prio) ok = false;
    if (onlyPending && done) ok = false;

    li.style.display = ok ? '' : 'none';
  });
}

/* ========= Drag & Drop reorder ========= */
function attachListDnD(){
  const list = el('#taskList');
  list.addEventListener('dragover', e => {
    e.preventDefault();
    const dragging = el('.task.dragging');
    if (!dragging) return;
    const after = getDragAfterElement(list, e.clientY);
    if (after == null) list.appendChild(dragging);
    else list.insertBefore(dragging, after);
  });
}
function getDragAfterElement(container, y){
  const els = [...container.querySelectorAll('.task:not(.dragging)')];
  return els.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) return { offset, element: child };
    else return closest;
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

async function sendOrder(){
  const ids = els('.task').map(li => Number(li.dataset.id));
  try { await API('reorder', {ids}); } catch(err){ alert(err.message); }
}

load();
