declare module 'vite/client';
