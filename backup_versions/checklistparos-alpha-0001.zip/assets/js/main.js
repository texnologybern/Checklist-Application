import { init } from './tasks.js';
import './filters.js';

document.addEventListener('DOMContentLoaded', init);
